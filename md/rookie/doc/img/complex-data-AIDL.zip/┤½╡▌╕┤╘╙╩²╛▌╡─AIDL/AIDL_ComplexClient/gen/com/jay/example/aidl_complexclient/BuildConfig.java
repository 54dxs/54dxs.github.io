/** Automatically generated file. DO NOT MODIFY */
package com.jay.example.aidl_complexclient;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}