package com.jay.http.test;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ServletForPost extends HttpServlet {
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		resp.setContentType("text/html;charset=utf-8");
		resp.setCharacterEncoding("UTF-8");
		Map<String,String> result = new HashMap<String,String>();
		String password=req.getParameter("passwd");
		String number=req.getParameter("number");
		if(password.equals("123") && number.equals("123"))
		{
			result.put("message", "��½�ɹ�");
		}else{
			result.put("message", "��½ʧ��");
		}
		byte[] bytes = result.toString().getBytes("utf-8");
		resp.setContentLength(bytes.length);
		resp.getOutputStream().write(bytes);
		resp.getOutputStream().flush();
		resp.getOutputStream().close();
	}
	
}
