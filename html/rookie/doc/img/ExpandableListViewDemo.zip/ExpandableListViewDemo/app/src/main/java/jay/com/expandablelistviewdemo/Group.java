package jay.com.expandablelistviewdemo;

/**
 * Created by Jay on 2015/9/25 0025.
 */
public class Group {
    private String gName;

    public Group() {
    }

    public Group(String gName) {
        this.gName = gName;
    }

    public String getgName() {
        return gName;
    }

    public void setgName(String gName) {
        this.gName = gName;
    }
}
