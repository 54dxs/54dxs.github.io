package com.jay.canvasdemo;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/**
 * Created by Jay on 2015/11/9 0009.
 */
public class MyView extends View {

    private Paint mPaint = null;
    private Bitmap bmp = null;

    public MyView(Context context) {
        this(context, null);
    }

    public MyView(Context context, AttributeSet attrs) {
        super(context, attrs);
        bmp = BitmapFactory.decodeResource(getResources(), R.mipmap.img_zb);
        init();
    }

    public MyView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
    }

    private void init() {
        mPaint = new Paint();
        mPaint.setColor(getResources().getColor(R.color.moss_tide));
        mPaint.setAntiAlias(true);
        mPaint.setStyle(Paint.Style.FILL);
        mPaint.setStrokeWidth(10);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        canvas.save();
        canvas.translate(300, 300);
        canvas.drawBitmap(bmp, 0, 0, mPaint);
        canvas.save();
        canvas.rotate(45);
        canvas.drawBitmap(bmp, 0, 0, mPaint);
        canvas.save();
        canvas.rotate(45);
        canvas.drawBitmap(bmp, 0, 0, mPaint);
        canvas.save();

        canvas.restoreToCount(1);
        canvas.translate(0, 200);
        canvas.drawBitmap(bmp, 0, 0, mPaint);






    }
}
