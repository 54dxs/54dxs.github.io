package com.jay.example.aidl_client;

import com.example.aidl.IPerson;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends Activity {

	private EditText editnum;
	private Button btnquery;
	private TextView txtshow;
	private IPerson iPerson;
	private PersonConnection conn = new PersonConnection();
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		editnum = (EditText) findViewById(R.id.editnum);
		btnquery = (Button) findViewById(R.id.btnquery);
		txtshow = (TextView) findViewById(R.id.txtshow);
		
		Intent service = new Intent("android.intent.action.AIDLService");
		bindService(service, conn, BIND_AUTO_CREATE);
		
		btnquery.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				String number = editnum.getText().toString();
				int num = Integer.valueOf(number);
				try {
					txtshow.setText(iPerson.queryPerson(num));
				} catch (RemoteException e) {
					e.printStackTrace();
				}
			}
		});
		
	}
	
	
	

	@Override
	protected void onDestroy() {
		unbindService(conn);
		super.onDestroy();
	}
	
	
	
	private final class PersonConnection implements ServiceConnection {
		public void onServiceConnected(ComponentName name, IBinder service) {
			iPerson = IPerson.Stub.asInterface(service);
		}
		public void onServiceDisconnected(ComponentName name) {
			iPerson = null;
		}
	}

}
