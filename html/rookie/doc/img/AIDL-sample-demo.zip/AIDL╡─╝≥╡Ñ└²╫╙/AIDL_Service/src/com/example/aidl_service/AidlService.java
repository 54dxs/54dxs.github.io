package com.example.aidl_service;

import com.example.aidl.IPerson.Stub;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.os.RemoteException;

public class AidlService extends Service {

	private IBinder binder = new PersonQueryBinder();
	private String[] names = {"С��","����ʦ","����","�ھ��"};
			
	@Override
	public IBinder onBind(Intent intent) {		
		return binder;
	}

	private String query(int num)
	{
		if(num > 0 && num < 5){
			return names[num - 1];
		}
		return null;
	}
	
	
	private final class PersonQueryBinder extends Stub{
		@Override
		public String queryPerson(int num) throws RemoteException {
			return query(num);
		}
	}
	
}
