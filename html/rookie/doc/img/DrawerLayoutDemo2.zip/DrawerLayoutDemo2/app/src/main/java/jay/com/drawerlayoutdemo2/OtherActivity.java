package jay.com.drawerlayoutdemo2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Jay on 2015/10/9 0009.
 */
public class OtherActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_other);
    }
}
