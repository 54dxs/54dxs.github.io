package com.jay.alarmmanagerdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by Jay on 2015/10/25 0025.
 */
public class AlarmReceiver extends BroadcastReceiver{
    @Override
    public void onReceive(Context context, Intent intent) {
        Intent i = new Intent(context,ClockActivity.class);
        i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        Log.e("HEHE","运行了~");
        context.startActivity(i);
    }
}
